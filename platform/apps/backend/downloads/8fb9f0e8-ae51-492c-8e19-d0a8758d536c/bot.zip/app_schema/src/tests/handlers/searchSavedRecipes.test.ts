
import { afterEach, beforeEach, describe } from "bun:test";
import { resetDB, createDB } from "../../helpers";
import { expect, it } from "bun:test";
import { eq } from "drizzle-orm";
import { db } from "../../db";
import { recipesTable, recipeIngredientsTable, recipeDietaryRestrictionsTable, ingredientsTable } from "../../db/schema/application";
import { type Recipe, type RecipeSearchRequest } from "../../common/schema";


import { handle as searchSavedRecipes } from "../../handlers/searchSavedRecipes.ts";


describe("", () => {
    beforeEach(async () => {
        await createDB();
    });


    afterEach(async () => {
        await resetDB();
    });
    
    
    it("should return empty array when no recipes exist", async () => {
      const options: RecipeSearchRequest = {};
      const recipes = await searchSavedRecipes(options);
      expect(recipes).toEqual([]);
    });

    
    
    it("should return all recipes when no filter is applied", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Pasta Carbonara",
          prepTimeMinutes: 10,
          cookTimeMinutes: 20,
          servings: 2,
          cuisineType: "Italian",
          mealType: "Dinner",
          difficultyLevel: "Easy"
        },
        {
          id: "recipe2",
          name: "Chicken Curry",
          prepTimeMinutes: 15,
          cookTimeMinutes: 30,
          servings: 4,
          cuisineType: "Indian",
          mealType: "Dinner",
          difficultyLevel: "Medium"
        }
      ]);
      
      const options: RecipeSearchRequest = {};
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(2);
      expect(recipes.map(r => r.id).sort()).toEqual(["recipe1", "recipe2"]);
    });

    
    
    it("should filter recipes by cuisine type", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Pasta Carbonara",
          prepTimeMinutes: 10,
          cookTimeMinutes: 20,
          servings: 2,
          cuisineType: "Italian",
          mealType: "Dinner",
          difficultyLevel: "Easy"
        },
        {
          id: "recipe2",
          name: "Chicken Curry",
          prepTimeMinutes: 15,
          cookTimeMinutes: 30,
          servings: 4,
          cuisineType: "Indian",
          mealType: "Dinner",
          difficultyLevel: "Medium"
        }
      ]);
      
      const options: RecipeSearchRequest = { cuisineType: "Italian" };
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(1);
      expect(recipes[0].id).toEqual("recipe1");
      expect(recipes[0].cuisineType).toEqual("Italian");
    });

    
    
    it("should filter recipes by meal type", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Pasta Carbonara",
          prepTimeMinutes: 10,
          cookTimeMinutes: 20,
          servings: 2,
          cuisineType: "Italian",
          mealType: "Dinner",
          difficultyLevel: "Easy"
        },
        {
          id: "recipe2",
          name: "Pancakes",
          prepTimeMinutes: 5,
          cookTimeMinutes: 10,
          servings: 2,
          cuisineType: "American",
          mealType: "Breakfast",
          difficultyLevel: "Easy"
        }
      ]);
      
      const options: RecipeSearchRequest = { mealType: "Breakfast" };
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(1);
      expect(recipes[0].id).toEqual("recipe2");
      expect(recipes[0].mealType).toEqual("Breakfast");
    });

    
    
    it("should filter recipes by dietary restrictions", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Vegetable Stir Fry",
          prepTimeMinutes: 10,
          cookTimeMinutes: 15,
          servings: 2,
          cuisineType: "Asian",
          mealType: "Dinner",
          difficultyLevel: "Easy"
        },
        {
          id: "recipe2",
          name: "Beef Burger",
          prepTimeMinutes: 10,
          cookTimeMinutes: 15,
          servings: 1,
          cuisineType: "American",
          mealType: "Lunch",
          difficultyLevel: "Medium"
        }
      ]);
      
      // Add dietary restrictions
      await db.insert(recipeDietaryRestrictionsTable).values([
        { recipeId: "recipe1", restriction: "Vegetarian" },
        { recipeId: "recipe1", restriction: "GlutenFree" },
        { recipeId: "recipe2", restriction: "None" }
      ]);
      
      const options: RecipeSearchRequest = { dietaryRestrictions: ["Vegetarian"] };
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(1);
      expect(recipes[0].id).toEqual("recipe1");
      expect(recipes[0].dietaryTags).toContain("Vegetarian");
    });

    
    
    it("should filter recipes by maximum preparation time", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Quick Salad",
          prepTimeMinutes: 5,
          cookTimeMinutes: 0,
          servings: 1,
          cuisineType: "Mediterranean",
          mealType: "Lunch",
          difficultyLevel: "Easy"
        },
        {
          id: "recipe2",
          name: "Lasagna",
          prepTimeMinutes: 30,
          cookTimeMinutes: 45,
          servings: 6,
          cuisineType: "Italian",
          mealType: "Dinner",
          difficultyLevel: "Hard"
        }
      ]);
      
      const options: RecipeSearchRequest = { maxPrepTime: "10" };
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(1);
      expect(recipes[0].id).toEqual("recipe1");
      expect(recipes[0].prepTime).toBeLessThanOrEqual("10:00");
    });

    
    
    it("should filter recipes by keyword in recipe name", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Chocolate Cake",
          prepTimeMinutes: 20,
          cookTimeMinutes: 35,
          servings: 8,
          cuisineType: "International",
          mealType: "Dessert",
          difficultyLevel: "Medium"
        },
        {
          id: "recipe2",
          name: "Vanilla Ice Cream",
          prepTimeMinutes: 15,
          cookTimeMinutes: 0,
          servings: 4,
          cuisineType: "International",
          mealType: "Dessert",
          difficultyLevel: "Easy"
        }
      ]);
      
      const options: RecipeSearchRequest = { keyword: "chocolate" };
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(1);
      expect(recipes[0].id).toEqual("recipe1");
      expect(recipes[0].name.toLowerCase()).toContain("chocolate");
    });

    
    
    it("should combine multiple filter criteria", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Vegetable Curry",
          prepTimeMinutes: 15,
          cookTimeMinutes: 25,
          servings: 4,
          cuisineType: "Indian",
          mealType: "Dinner",
          difficultyLevel: "Medium"
        },
        {
          id: "recipe2",
          name: "Vegetable Pasta",
          prepTimeMinutes: 10,
          cookTimeMinutes: 15,
          servings: 2,
          cuisineType: "Italian",
          mealType: "Dinner",
          difficultyLevel: "Easy"
        },
        {
          id: "recipe3",
          name: "Butter Chicken",
          prepTimeMinutes: 20,
          cookTimeMinutes: 30,
          servings: 4,
          cuisineType: "Indian",
          mealType: "Dinner",
          difficultyLevel: "Medium"
        }
      ]);
      
      // Add dietary restrictions
      await db.insert(recipeDietaryRestrictionsTable).values([
        { recipeId: "recipe1", restriction: "Vegetarian" },
        { recipeId: "recipe2", restriction: "Vegetarian" }
      ]);
      
      const options: RecipeSearchRequest = {
        cuisineType: "Indian",
        dietaryRestrictions: ["Vegetarian"],
        keyword: "vegetable"
      };
      
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toHaveLength(1);
      expect(recipes[0].id).toEqual("recipe1");
      expect(recipes[0].cuisineType).toEqual("Indian");
      expect(recipes[0].dietaryTags).toContain("Vegetarian");
      expect(recipes[0].name.toLowerCase()).toContain("vegetable");
    });

    
    
    it("should return empty array when no recipes match the criteria", async () => {
      // Insert test recipes
      await db.insert(recipesTable).values([
        {
          id: "recipe1",
          name: "Beef Steak",
          prepTimeMinutes: 10,
          cookTimeMinutes: 15,
          servings: 1,
          cuisineType: "American",
          mealType: "Dinner",
          difficultyLevel: "Medium"
        }
      ]);
      
      // Add dietary restrictions
      await db.insert(recipeDietaryRestrictionsTable).values([
        { recipeId: "recipe1", restriction: "None" }
      ]);
      
      const options: RecipeSearchRequest = { dietaryRestrictions: ["Vegan"] };
      const recipes = await searchSavedRecipes(options);
      
      expect(recipes).toEqual([]);
    });

    
});