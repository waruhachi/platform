import { eq, ilike, and, lte, inArray } from "drizzle-orm";
import { db } from "../db";
import { searchSavedRecipes, type RecipeSearchRequest } from "../common/schema";
import { 
  recipesTable,
  recipeIngredientsTable, 
  ingredientsTable,
  recipeDietaryRestrictionsTable
} from "../db/schema/application";

export const handle: typeof searchSavedRecipes = async (options: RecipeSearchRequest): Promise<Array<{
  id: string;
  name: string;
  ingredients: Array<{
    name: string;
    quantity?: string | undefined;
    unit?: string | undefined;
  }>;
  prepTime: string;
  cookTime: string;
  servings: number;
  dietaryTags: Array<"Vegetarian" | "Vegan" | "GlutenFree" | "DairyFree" | "Keto" | "Paleo" | "LowCarb" | "None">;
  cuisineType: string;
  mealType: string;
  difficultyLevel: string;
}>> => {
  // Build up query conditions based on provided options
  const conditions = [];
  
  // Filter by cuisine type if provided
  if (options.cuisineType) {
    conditions.push(eq(recipesTable.cuisineType, options.cuisineType));
  }
  
  // Filter by meal type if provided
  if (options.mealType) {
    conditions.push(eq(recipesTable.mealType, options.mealType));
  }
  
  // Filter by keyword in recipe name if provided
  if (options.keyword) {
    conditions.push(ilike(recipesTable.name, `%${options.keyword}%`));
  }
  
  // Filter by maximum prep time if provided
  if (options.maxPrepTime) {
    // Convert string duration to minutes for comparison
    const maxMinutes = parseDurationToMinutes(options.maxPrepTime);
    if (maxMinutes > 0) {
      conditions.push(lte(recipesTable.prepTimeMinutes, maxMinutes));
    }
  }

  // Get all recipes matching the conditions
  const recipes = await db.select({
    id: recipesTable.id,
    name: recipesTable.name,
    prepTimeMinutes: recipesTable.prepTimeMinutes,
    cookTimeMinutes: recipesTable.cookTimeMinutes,
    servings: recipesTable.servings,
    cuisineType: recipesTable.cuisineType,
    mealType: recipesTable.mealType,
    difficultyLevel: recipesTable.difficultyLevel,
  })
  .from(recipesTable)
  .where(conditions.length > 0 ? and(...conditions) : undefined)
  .execute();
  
  // If no recipes found or no options provided, return empty array
  if (recipes.length === 0) {
    return [];
  }
  
  // Get recipe IDs to fetch related data
  const recipeIds = recipes.map(recipe => recipe.id);
  
  // Fetch dietary restrictions for all recipes
  const dietaryRestrictions = await db
    .select({
      recipeId: recipeDietaryRestrictionsTable.recipeId,
      restriction: recipeDietaryRestrictionsTable.restriction,
    })
    .from(recipeDietaryRestrictionsTable)
    .where(inArray(recipeDietaryRestrictionsTable.recipeId, recipeIds))
    .execute();
  
  // Group dietary restrictions by recipe ID
  const dietaryRestrictionsMap = dietaryRestrictions.reduce((acc, { recipeId, restriction }) => {
    if (!acc[recipeId]) {
      acc[recipeId] = [];
    }
    acc[recipeId].push(restriction);
    return acc;
  }, {} as Record<string, Array<"Vegetarian" | "Vegan" | "GlutenFree" | "DairyFree" | "Keto" | "Paleo" | "LowCarb" | "None">>);
  
  // Filter recipes by dietary restrictions if provided
  let filteredRecipeIds = recipeIds;
  if (options.dietaryRestrictions && options.dietaryRestrictions.length > 0) {
    filteredRecipeIds = recipeIds.filter(id => {
      const recipeDietaryRestrictions = dietaryRestrictionsMap[id] || [];
      return options.dietaryRestrictions!.every(restriction => 
        recipeDietaryRestrictions.includes(restriction)
      );
    });
    
    // If no recipes match dietary restrictions, return empty array
    if (filteredRecipeIds.length === 0) {
      return [];
    }
  }
  
  // Fetch ingredients for all filtered recipes
  const recipeIngredients = await db
    .select({
      recipeId: recipeIngredientsTable.recipeId,
      ingredientName: ingredientsTable.name,
      quantity: recipeIngredientsTable.quantity,
      unit: recipeIngredientsTable.unit,
    })
    .from(recipeIngredientsTable)
    .innerJoin(ingredientsTable, eq(recipeIngredientsTable.ingredientId, ingredientsTable.id))
    .where(inArray(recipeIngredientsTable.recipeId, filteredRecipeIds))
    .execute();
  
  // Group ingredients by recipe ID
  const ingredientsMap = recipeIngredients.reduce((acc, { recipeId, ingredientName, quantity, unit }) => {
    if (!acc[recipeId]) {
      acc[recipeId] = [];
    }
    acc[recipeId].push({
      name: ingredientName,
      quantity: quantity ?? undefined,
      unit: unit ?? undefined,
    });
    return acc;
  }, {} as Record<string, Array<{ name: string; quantity?: string; unit?: string }>>);
  
  // Format results to match Recipe schema
  const formattedRecipes = recipes
    .filter(recipe => filteredRecipeIds.includes(recipe.id))
    .map(recipe => ({
      id: recipe.id,
      name: recipe.name,
      ingredients: ingredientsMap[recipe.id] || [],
      // Ensure we're using our helper function that can handle different input types
      prepTime: durationToString(recipe.prepTimeMinutes),
      cookTime: durationToString(recipe.cookTimeMinutes),
      servings: recipe.servings,
      dietaryTags: dietaryRestrictionsMap[recipe.id] || [],
      cuisineType: recipe.cuisineType,
      mealType: recipe.mealType,
      difficultyLevel: recipe.difficultyLevel,
    }));
  
  return formattedRecipes;
};

// Helper function to parse duration string to minutes
function parseDurationToMinutes(duration: string): number {
  // Simple implementation - assumes format like "30m" or "1h 30m"
  const hourMatch = duration.match(/(\d+)\s*h/);
  const minuteMatch = duration.match(/(\d+)\s*m/);
  
  let totalMinutes = 0;
  if (hourMatch) {
    totalMinutes += parseInt(hourMatch[1], 10) * 60;
  }
  if (minuteMatch) {
    totalMinutes += parseInt(minuteMatch[1], 10);
  }
  
  return totalMinutes;
}

/**
 * Converts a duration in minutes or a duration string to a formatted string
 * This version is designed to be more resilient by handling various input types
 */
function durationToString(input: unknown): string {
  // Handle undefined or null
  if (input == null) {
    return "0m";
  }
  
  // Convert input to number if possible
  let minutes = 0;
  
  if (typeof input === "number") {
    minutes = input;
  } else if (typeof input === "string") {
    // If input is already in format like "1h 30m", return as is
    if (input.includes("h") || input.includes("m")) {
      return input;
    }
    // Otherwise try to parse as a number
    const parsed = parseInt(input, 10);
    if (!isNaN(parsed)) {
      minutes = parsed;
    }
  }
  
  // Format the duration
  if (minutes < 60) {
    return `${minutes}m`;
  }
  
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  if (remainingMinutes === 0) {
    return `${hours}h`;
  }
  
  return `${hours}h ${remainingMinutes}m`;
}