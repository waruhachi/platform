
import { afterEach, beforeEach, describe } from "bun:test";
import { resetDB, createDB } from "../../helpers";
import { expect, it } from "bun:test";
import { db } from "../../db";
import { eq } from "drizzle-orm";
import { type RecipeDetailsRequest, type Recipe, type RecipeDetails } from "../../common/schema";
import { recipesTable, recipeDetailsTable, recipeIngredientsTable, recipeDietaryRestrictionsTable, ingredientsTable } from "../../db/schema/application";

import { handle as getRecipeDetails } from "../../handlers/getRecipeDetails.ts";


describe("", () => {
    beforeEach(async () => {
        await createDB();
    });


    afterEach(async () => {
        await resetDB();
    });
    
    
    it("should return recipe details for a valid recipe id", async () => {
      // Insert a recipe
      const recipeId = "recipe-123";
      await db.insert(recipesTable).values({
        id: recipeId,
        name: "Pasta Primavera",
        prepTimeMinutes: 15,
        cookTimeMinutes: 20,
        servings: 4,
        cuisineType: "Italian",
        mealType: "Dinner",
        difficultyLevel: "Easy"
      });

      // Insert recipe details
      await db.insert(recipeDetailsTable).values({
        recipeId: recipeId,
        instructions: ["Boil pasta", "Sauté vegetables", "Mix together", "Serve hot"],
        nutritionalInfo: "Calories: 400, Protein: 12g, Carbs: 65g, Fat: 10g"
      });

      // Insert ingredients for the recipe
      const garlic = await db.insert(ingredientsTable).values({ name: "Garlic" }).returning({ id: ingredientsTable.id });
      const pasta = await db.insert(ingredientsTable).values({ name: "Pasta" }).returning({ id: ingredientsTable.id });
      const oil = await db.insert(ingredientsTable).values({ name: "Olive Oil" }).returning({ id: ingredientsTable.id });

      // Connect ingredients to recipe
      await db.insert(recipeIngredientsTable).values([
        { recipeId: recipeId, ingredientId: garlic[0].id, quantity: "2", unit: "cloves" },
        { recipeId: recipeId, ingredientId: pasta[0].id, quantity: "200", unit: "g" },
        { recipeId: recipeId, ingredientId: oil[0].id, quantity: "2", unit: "tbsp" }
      ]);

      // Add dietary restrictions
      await db.insert(recipeDietaryRestrictionsTable).values([
        { recipeId: recipeId, restriction: "Vegetarian" }
      ]);

      // Execute the function
      const request: RecipeDetailsRequest = { recipeId: recipeId };
      const result = await getRecipeDetails(request);

      // Assertions
      expect(result).toBeDefined();
      expect(result.recipe.id).toEqual(recipeId);
      expect(result.recipe.name).toEqual("Pasta Primavera");
      expect(result.instructions).toHaveLength(4);
      expect(result.instructions).toContain("Boil pasta");
      expect(result.nutritionalInfo).toContain("Calories: 400");
      expect(result.recipe.ingredients).toHaveLength(3);
      expect(result.recipe.ingredients.some(i => i.name === "Garlic" && i.quantity === "2" && i.unit === "cloves")).toBeTrue();
      expect(result.recipe.dietaryTags).toContain("Vegetarian");
    });

    
    
    it("should throw an error if recipe id does not exist", async () => {
      const request: RecipeDetailsRequest = { recipeId: "non-existent-id" };
      
      await expect(async () => {
        await getRecipeDetails(request);
      }).toThrow(/Recipe not found/);
    });

    
    
    it("should correctly map database fields to recipe structure", async () => {
      // Insert a recipe
      const recipeId = "recipe-456";
      await db.insert(recipesTable).values({
        id: recipeId,
        name: "Avocado Toast",
        prepTimeMinutes: 5,
        cookTimeMinutes: 2,
        servings: 1,
        cuisineType: "Breakfast",
        mealType: "Breakfast",
        difficultyLevel: "Easy"
      });

      // Insert recipe details
      await db.insert(recipeDetailsTable).values({
        recipeId: recipeId,
        instructions: ["Toast bread", "Mash avocado", "Spread on toast", "Add salt and pepper"],
        nutritionalInfo: "Calories: 320, Protein: 8g, Carbs: 25g, Fat: 22g"
      });

      // Insert ingredients for the recipe
      const avocado = await db.insert(ingredientsTable).values({ name: "Avocado" }).returning({ id: ingredientsTable.id });
      const bread = await db.insert(ingredientsTable).values({ name: "Sourdough bread" }).returning({ id: ingredientsTable.id });
      
      await db.insert(recipeIngredientsTable).values([
        { recipeId: recipeId, ingredientId: avocado[0].id, quantity: "1", unit: "whole" },
        { recipeId: recipeId, ingredientId: bread[0].id, quantity: "2", unit: "slices" }
      ]);

      // Add dietary restrictions
      await db.insert(recipeDietaryRestrictionsTable).values([
        { recipeId: recipeId, restriction: "Vegetarian" },
        { recipeId: recipeId, restriction: "Vegan" }
      ]);

      // Execute the function
      const request: RecipeDetailsRequest = { recipeId: recipeId };
      const result = await getRecipeDetails(request);

      // Assertions on proper mapping
      expect(result.recipe).toMatchObject({
        id: recipeId,
        name: "Avocado Toast",
        prepTime: "5", // This should be converted from minutes to string format
        cookTime: "2", // This should be converted from minutes to string format
        servings: 1,
        cuisineType: "Breakfast",
        mealType: "Breakfast",
        difficultyLevel: "Easy"
      });

      // Check dietary tags
      expect(result.recipe.dietaryTags).toHaveLength(2);
      expect(result.recipe.dietaryTags).toContain("Vegetarian");
      expect(result.recipe.dietaryTags).toContain("Vegan");

      // Check ingredients
      expect(result.recipe.ingredients).toHaveLength(2);
      const avocadoIngredient = result.recipe.ingredients.find(i => i.name === "Avocado");
      expect(avocadoIngredient).toBeDefined();
      expect(avocadoIngredient?.quantity).toEqual("1");
      expect(avocadoIngredient?.unit).toEqual("whole");
    });

    
    
    it("should return complete recipe details including all related data", async () => {
      // Insert a recipe
      const recipeId = "recipe-789";
      await db.insert(recipesTable).values({
        id: recipeId,
        name: "Chicken Stir Fry",
        prepTimeMinutes: 20,
        cookTimeMinutes: 15,
        servings: 2,
        cuisineType: "Asian",
        mealType: "Dinner",
        difficultyLevel: "Medium"
      });

      // Insert various ingredients
      const chicken = await db.insert(ingredientsTable).values({ name: "Chicken breast" }).returning({ id: ingredientsTable.id });
      const bellPepper = await db.insert(ingredientsTable).values({ name: "Bell pepper" }).returning({ id: ingredientsTable.id });
      const broccoli = await db.insert(ingredientsTable).values({ name: "Broccoli" }).returning({ id: ingredientsTable.id });
      const soySauce = await db.insert(ingredientsTable).values({ name: "Soy sauce" }).returning({ id: ingredientsTable.id });
      const rice = await db.insert(ingredientsTable).values({ name: "Rice" }).returning({ id: ingredientsTable.id });

      // Connect ingredients to recipe
      await db.insert(recipeIngredientsTable).values([
        { recipeId: recipeId, ingredientId: chicken[0].id, quantity: "250", unit: "g" },
        { recipeId: recipeId, ingredientId: bellPepper[0].id, quantity: "1", unit: "medium" },
        { recipeId: recipeId, ingredientId: broccoli[0].id, quantity: "150", unit: "g" },
        { recipeId: recipeId, ingredientId: soySauce[0].id, quantity: "30", unit: "ml" },
        { recipeId: recipeId, ingredientId: rice[0].id, quantity: "1", unit: "cup" }
      ]);

      // Add detailed instructions and nutritional info
      await db.insert(recipeDetailsTable).values({
        recipeId: recipeId,
        instructions: [
          "Dice chicken into 1-inch cubes",
          "Chop vegetables into bite-sized pieces",
          "Heat oil in a wok over high heat",
          "Stir-fry chicken until golden",
          "Add vegetables and stir-fry for 3 minutes",
          "Add soy sauce and continue cooking for 2 minutes",
          "Serve over cooked rice"
        ],
        nutritionalInfo: "Calories: 450, Protein: 35g, Carbs: 40g, Fat: 15g"
      });

      // Execute the function
      const request: RecipeDetailsRequest = { recipeId: recipeId };
      const details: RecipeDetails = await getRecipeDetails(request);

      // Assertions
      expect(details).toBeDefined();
      expect(details.recipe.name).toEqual("Chicken Stir Fry");
      expect(details.recipe.ingredients).toHaveLength(5);
      expect(details.instructions).toHaveLength(7);
      expect(details.recipe.prepTime).toEqual("20");
      expect(details.recipe.cookTime).toEqual("15");
      
      // Check specific ingredients
      const chickenIngredient = details.recipe.ingredients.find(i => i.name === "Chicken breast");
      expect(chickenIngredient).toBeDefined();
      expect(chickenIngredient?.quantity).toEqual("250");
      expect(chickenIngredient?.unit).toEqual("g");
      
      // Check instructions are in the right order
      expect(details.instructions[0]).toEqual("Dice chicken into 1-inch cubes");
      expect(details.instructions[details.instructions.length - 1]).toEqual("Serve over cooked rice");
      
      // Check nutritional info
      expect(details.nutritionalInfo).toEqual("Calories: 450, Protein: 35g, Carbs: 40g, Fat: 15g");
    });

    
});