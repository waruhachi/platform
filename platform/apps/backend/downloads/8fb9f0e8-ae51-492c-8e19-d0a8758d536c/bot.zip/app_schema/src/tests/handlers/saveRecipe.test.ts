
import { afterEach, beforeEach, describe } from "bun:test";
import { resetDB, createDB } from "../../helpers";
import { expect, it, mock } from "bun:test";
import { db } from "../../db";
import { eq } from "drizzle-orm";
import { recipesTable, recipeIngredientsTable, recipeDietaryRestrictionsTable, ingredientsTable } from "../../db/schema/application";
import { type SaveRecipeRequest, type Recipe } from "../../common/schema";

import { handle as saveRecipe } from "../../handlers/saveRecipe.ts";


describe("", () => {
    beforeEach(async () => {
        await createDB();
    });


    afterEach(async () => {
        await resetDB();
    });
    
    
    it("should save recipe to the database", async () => {
      // Arrange
      const mockRecipe: Recipe = {
        id: "recipe123",
        name: "Test Recipe",
        ingredients: [{ name: "Tomato", quantity: "2", unit: "pieces" }],
        prepTime: "15 minutes",
        cookTime: "30 minutes",
        servings: 4,
        dietaryTags: ["Vegetarian", "GlutenFree"],
        cuisineType: "Italian",
        mealType: "Dinner",
        difficultyLevel: "Easy"
      };
      
      const request: SaveRecipeRequest = {
        recipe: mockRecipe
      };
      
      // Act
      await saveRecipe(request);
      
      // Assert
      const savedRecipe = await db
        .select()
        .from(recipesTable)
        .where(eq(recipesTable.id, mockRecipe.id))
        .execute();
      
      expect(savedRecipe).toHaveLength(1);
      expect(savedRecipe[0].name).toEqual("Test Recipe");
      expect(savedRecipe[0].cuisineType).toEqual("Italian");
      expect(savedRecipe[0].mealType).toEqual("Dinner");
      expect(savedRecipe[0].difficultyLevel).toEqual("Easy");
      expect(savedRecipe[0].servings).toEqual(4);
    });

    
    
    it("should save recipe ingredients correctly", async () => {
      // Arrange
      const mockRecipe: Recipe = {
        id: "recipe456",
        name: "Pasta dish",
        ingredients: [
          { name: "Pasta", quantity: "200", unit: "g" },
          { name: "Tomato sauce", quantity: "100", unit: "ml" }
        ],
        prepTime: "10 minutes",
        cookTime: "15 minutes",
        servings: 2,
        dietaryTags: ["Vegetarian"],
        cuisineType: "Italian",
        mealType: "Lunch",
        difficultyLevel: "Easy"
      };
      
      const request: SaveRecipeRequest = {
        recipe: mockRecipe
      };
      
      // Act
      await saveRecipe(request);
      
      // Assert
      // First check if ingredients were created
      const ingredients = await db
        .select()
        .from(ingredientsTable)
        .execute();
      
      expect(ingredients.length).toBeGreaterThanOrEqual(2);
      
      // Check recipe ingredients
      const recipeIngredients = await db
        .select()
        .from(recipeIngredientsTable)
        .where(eq(recipeIngredientsTable.recipeId, mockRecipe.id))
        .execute();
      
      expect(recipeIngredients).toHaveLength(2);
      
      // Check quantities and units
      const pastaIngredient = recipeIngredients.find(
        ri => ingredients.find(i => i.id === ri.ingredientId)?.name === "Pasta"
      );
      
      expect(pastaIngredient).toBeDefined();
      expect(pastaIngredient?.quantity).toEqual("200");
      expect(pastaIngredient?.unit).toEqual("g");
    });

    
    
    it("should save dietary restrictions correctly", async () => {
      // Arrange
      const mockRecipe: Recipe = {
        id: "recipe789",
        name: "Healthy Salad",
        ingredients: [
          { name: "Lettuce", quantity: "1", unit: "head" },
          { name: "Tomato", quantity: "2", unit: "pieces" }
        ],
        prepTime: "10 minutes",
        cookTime: "0 minutes",
        servings: 2,
        dietaryTags: ["Vegan", "GlutenFree", "DairyFree"],
        cuisineType: "Mediterranean",
        mealType: "Lunch",
        difficultyLevel: "Easy"
      };
      
      const request: SaveRecipeRequest = {
        recipe: mockRecipe
      };
      
      // Act
      await saveRecipe(request);
      
      // Assert
      const dietaryRestrictions = await db
        .select()
        .from(recipeDietaryRestrictionsTable)
        .where(eq(recipeDietaryRestrictionsTable.recipeId, mockRecipe.id))
        .execute();
      
      expect(dietaryRestrictions).toHaveLength(3);
      
      const restrictions = dietaryRestrictions.map(dr => dr.restriction);
      expect(restrictions).toContain("Vegan");
      expect(restrictions).toContain("GlutenFree");
      expect(restrictions).toContain("DairyFree");
    });

    
    
    it("should convert time strings to minutes", async () => {
      // Arrange
      const mockRecipe: Recipe = {
        id: "timerecipe123",
        name: "Time Test Recipe",
        ingredients: [{ name: "Ingredient", quantity: "1", unit: "unit" }],
        prepTime: "45 minutes",
        cookTime: "1 hour 30 minutes",
        servings: 4,
        dietaryTags: ["None"],
        cuisineType: "American",
        mealType: "Dinner",
        difficultyLevel: "Medium"
      };
      
      const request: SaveRecipeRequest = {
        recipe: mockRecipe
      };
      
      // Act
      await saveRecipe(request);
      
      // Assert
      const savedRecipe = await db
        .select()
        .from(recipesTable)
        .where(eq(recipesTable.id, mockRecipe.id))
        .execute();
      
      expect(savedRecipe[0].prepTimeMinutes).toEqual(45);
      expect(savedRecipe[0].cookTimeMinutes).toEqual(90); // 1 hour 30 minutes = 90 minutes
    });

    
    
    it("should handle recipe with no dietary restrictions", async () => {
      // Arrange
      const mockRecipe: Recipe = {
        id: "plainrecipe123",
        name: "Basic Recipe",
        ingredients: [{ name: "Water", quantity: "2", unit: "cups" }],
        prepTime: "5 minutes",
        cookTime: "10 minutes",
        servings: 1,
        dietaryTags: [],
        cuisineType: "Basic",
        mealType: "Snack",
        difficultyLevel: "Easy"
      };
      
      const request: SaveRecipeRequest = {
        recipe: mockRecipe
      };
      
      // Act
      await saveRecipe(request);
      
      // Assert
      const dietaryRestrictions = await db
        .select()
        .from(recipeDietaryRestrictionsTable)
        .where(eq(recipeDietaryRestrictionsTable.recipeId, mockRecipe.id))
        .execute();
      
      expect(dietaryRestrictions).toHaveLength(0);
      
      const savedRecipe = await db
        .select()
        .from(recipesTable)
        .where(eq(recipesTable.id, mockRecipe.id))
        .execute();
      
      expect(savedRecipe).toHaveLength(1);
    });

    
    
    it("should handle ingredients with missing optional fields", async () => {
      // Arrange
      const mockRecipe: Recipe = {
        id: "incomplete123",
        name: "Recipe with incomplete ingredients",
        ingredients: [
          { name: "Salt" }, // No quantity or unit
          { name: "Pepper", quantity: "to taste" }, // No unit
          { name: "Flour", unit: "cups" } // No quantity
        ],
        prepTime: "5 minutes",
        cookTime: "0 minutes",
        servings: 4,
        dietaryTags: ["Vegetarian"],
        cuisineType: "Universal",
        mealType: "Any",
        difficultyLevel: "Easy"
      };
      
      const request: SaveRecipeRequest = {
        recipe: mockRecipe
      };
      
      // Act
      await saveRecipe(request);
      
      // Assert
      const recipeIngredients = await db
        .select()
        .from(recipeIngredientsTable)
        .where(eq(recipeIngredientsTable.recipeId, mockRecipe.id))
        .execute();
      
      expect(recipeIngredients).toHaveLength(3);
      
      // Check ingredients were saved with their optional fields properly
      const ingredients = await db
        .select()
        .from(ingredientsTable)
        .execute();
      
      const salt = recipeIngredients.find(
        ri => ingredients.find(i => i.id === ri.ingredientId)?.name === "Salt"
      );
      expect(salt?.quantity).toBeNull();
      expect(salt?.unit).toBeNull();
      
      const pepper = recipeIngredients.find(
        ri => ingredients.find(i => i.id === ri.ingredientId)?.name === "Pepper"
      );
      expect(pepper?.quantity).toEqual("to taste");
      expect(pepper?.unit).toBeNull();
    });

    
});