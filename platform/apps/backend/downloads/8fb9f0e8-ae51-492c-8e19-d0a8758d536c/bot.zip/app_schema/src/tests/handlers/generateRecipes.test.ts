
import { afterEach, beforeEach, describe } from "bun:test";
import { resetDB, createDB } from "../../helpers";
import { expect, it, mock } from "bun:test";
import { db } from "../../db";
import { recipesTable, recipeIngredientsTable, recipeDietaryRestrictionsTable } from "../../db/schema/application";
import { type RecipeRequest, type Recipe, type Ingredient, type DietaryRestriction } from "../../common/schema";

import { eq } from "drizzle-orm";

import { handle as generateRecipes } from "../../handlers/generateRecipes.ts";


describe("", () => {
    beforeEach(async () => {
        await createDB();
    });


    afterEach(async () => {
        await resetDB();
    });
    
    
    it("should generate recipes with provided ingredients", async () => {
      const request: RecipeRequest = {
        ingredients: [
          { name: "chicken breast", quantity: "500", unit: "g" },
          { name: "garlic", quantity: "2", unit: "cloves" },
          { name: "olive oil", quantity: "2", unit: "tbsp" }
        ]
      };
      
      const recipes = await generateRecipes(request);
      
      expect(recipes).toBeArray();
      expect(recipes.length).toBeGreaterThan(0);
      recipes.forEach(recipe => {
        expect(recipe.id).toBeString();
        expect(recipe.name).toBeString();
        expect(recipe.prepTime).toBeString();
        expect(recipe.cookTime).toBeString();
        expect(recipe.servings).toBeNumber();
        expect(recipe.ingredients).toBeArray();
        expect(recipe.dietaryTags).toBeArray();
      });
    });

    
    
    it("should respect dietary restrictions when generating recipes", async () => {
      const dietaryRestrictions: DietaryRestriction[] = ["Vegetarian", "GlutenFree"];
      const request: RecipeRequest = {
        ingredients: [
          { name: "tofu", quantity: "400", unit: "g" },
          { name: "bell pepper", quantity: "1", unit: "piece" }
        ],
        dietaryRestrictions
      };
      
      const recipes = await generateRecipes(request);
      
      expect(recipes).toBeArray();
      expect(recipes.length).toBeGreaterThan(0);
      recipes.forEach(recipe => {
        expect(recipe.dietaryTags).toContain("Vegetarian");
        expect(recipe.dietaryTags).toContain("GlutenFree");
      });
    });

    
    
    it("should generate recipes with specified cuisine type", async () => {
      const cuisineType = "Italian";
      const request: RecipeRequest = {
        ingredients: [
          { name: "pasta", quantity: "250", unit: "g" },
          { name: "tomatoes", quantity: "4", unit: "pieces" }
        ],
        cuisineType
      };
      
      const recipes = await generateRecipes(request);
      
      expect(recipes).toBeArray();
      expect(recipes.length).toBeGreaterThan(0);
      recipes.forEach(recipe => {
        expect(recipe.cuisineType).toBe(cuisineType);
      });
    });

    
    
    it("should respect max preparation time when generating recipes", async () => {
      const maxPrepTime = "30 minutes";
      const request: RecipeRequest = {
        ingredients: [
          { name: "eggs", quantity: "4", unit: "pieces" },
          { name: "cheese", quantity: "100", unit: "g" }
        ],
        maxPrepTime
      };
      
      const recipes = await generateRecipes(request);
      
      expect(recipes).toBeArray();
      expect(recipes.length).toBeGreaterThan(0);
      
      // Parse time strings to check if they're within the max prep time
      recipes.forEach(recipe => {
        const prepTimeMinutes = parseInt(recipe.prepTime.split(" ")[0]);
        expect(prepTimeMinutes).toBeLessThanOrEqual(30);
      });
    });

    
    
    it("should generate recipes of the specified meal type", async () => {
      const mealType = "Breakfast";
      const request: RecipeRequest = {
        ingredients: [
          { name: "bread", quantity: "4", unit: "slices" },
          { name: "avocado", quantity: "1", unit: "piece" }
        ],
        mealType
      };
      
      const recipes = await generateRecipes(request);
      
      expect(recipes).toBeArray();
      expect(recipes.length).toBeGreaterThan(0);
      recipes.forEach(recipe => {
        expect(recipe.mealType).toBe(mealType);
      });
    });

    
    
    it("should handle empty ingredients list", async () => {
      const request: RecipeRequest = {
        ingredients: []
      };
      
      await expect(async () => {
        await generateRecipes(request);
      }).toThrow();
    });

    
    
    it("should generate recipes with all specified constraints", async () => {
      const request: RecipeRequest = {
        ingredients: [
          { name: "rice", quantity: "200", unit: "g" },
          { name: "vegetables", quantity: "300", unit: "g" }
        ],
        dietaryRestrictions: ["Vegan"],
        cuisineType: "Asian",
        maxPrepTime: "20 minutes",
        mealType: "Dinner"
      };
      
      const recipes = await generateRecipes(request);
      
      expect(recipes).toBeArray();
      expect(recipes.length).toBeGreaterThan(0);
      recipes.forEach(recipe => {
        expect(recipe.dietaryTags).toContain("Vegan");
        expect(recipe.cuisineType).toBe("Asian");
        expect(recipe.mealType).toBe("Dinner");
        
        const prepTimeMinutes = parseInt(recipe.prepTime.split(" ")[0]);
        expect(prepTimeMinutes).toBeLessThanOrEqual(20);
      });
    });

    
    
    it("should not modify input ingredients", async () => {
      const ingredients: Ingredient[] = [
        { name: "potatoes", quantity: "500", unit: "g" },
        { name: "onions", quantity: "2", unit: "pieces" }
      ];
      
      const originalIngredients = JSON.parse(JSON.stringify(ingredients));
      
      const request: RecipeRequest = {
        ingredients
      };
      
      await generateRecipes(request);
      
      expect(ingredients).toEqual(originalIngredients);
    });

    
});