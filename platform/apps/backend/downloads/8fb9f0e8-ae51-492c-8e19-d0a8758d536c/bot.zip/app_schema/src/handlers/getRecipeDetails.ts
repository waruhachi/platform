import { eq } from "drizzle-orm";
import { db } from "../db";
import { type RecipeDetailsRequest, type RecipeDetails, getRecipeDetails } from "../common/schema";
import { 
  recipesTable, 
  recipeDetailsTable, 
  recipeIngredientsTable,
  recipeDietaryRestrictionsTable, 
  ingredientsTable 
} from "../db/schema/application";

export const handle: typeof getRecipeDetails = async (options: RecipeDetailsRequest): Promise<RecipeDetails> => {
  // Get the basic recipe information
  const recipe = await db.select()
    .from(recipesTable)
    .where(eq(recipesTable.id, options.recipeId))
    .limit(1);

  if (recipe.length === 0) {
    throw new Error(`Recipe not found`);
  }

  // Get recipe details (instructions and nutritional info)
  const recipeDetails = await db.select()
    .from(recipeDetailsTable)
    .where(eq(recipeDetailsTable.recipeId, options.recipeId))
    .limit(1);

  // Get recipe ingredients
  const ingredientsQuery = db.select({
    name: ingredientsTable.name,
    quantity: recipeIngredientsTable.quantity,
    unit: recipeIngredientsTable.unit
  })
  .from(recipeIngredientsTable)
  .innerJoin(ingredientsTable, eq(recipeIngredientsTable.ingredientId, ingredientsTable.id))
  .where(eq(recipeIngredientsTable.recipeId, options.recipeId));

  const ingredients = await ingredientsQuery;

  // Get dietary restrictions
  const dietaryRestrictionsQuery = db.select({
    restriction: recipeDietaryRestrictionsTable.restriction
  })
  .from(recipeDietaryRestrictionsTable)
  .where(eq(recipeDietaryRestrictionsTable.recipeId, options.recipeId));

  const dietaryRestrictions = await dietaryRestrictionsQuery;

  // Format prep and cook times from minutes to string format - use just the number as string
  const prepTime = String(recipe[0].prepTimeMinutes);
  const cookTime = String(recipe[0].cookTimeMinutes);

  // Handle nutritionalInfo correctly - convert null to undefined
  const nutritionalInfo = recipeDetails[0]?.nutritionalInfo ?? undefined;

  return {
    recipe: {
      id: recipe[0].id,
      name: recipe[0].name,
      ingredients: ingredients.map(ing => ({
        name: ing.name,
        quantity: ing.quantity || undefined,
        unit: ing.unit || undefined
      })),
      prepTime,
      cookTime,
      servings: recipe[0].servings,
      dietaryTags: dietaryRestrictions.map(dr => dr.restriction),
      cuisineType: recipe[0].cuisineType,
      mealType: recipe[0].mealType,
      difficultyLevel: recipe[0].difficultyLevel
    },
    instructions: recipeDetails[0]?.instructions || [],
    nutritionalInfo
  };
};