import { db } from "../db";
import { eq } from "drizzle-orm";
import type { Recipe, RecipeRequest } from "../common/schema";
import { generateRecipes } from "../common/schema";
import { recipesTable, ingredientsTable, recipeIngredientsTable, recipeDietaryRestrictionsTable } from "../db/schema/application";
import { randomUUID } from "crypto";

// Difficulty levels based on preparation time
const getDifficultyLevel = (prepTime: string): string => {
  const minutes = parseInt(prepTime.replace(/\D/g, ""), 10);
  if (minutes <= 15) return "Easy";
  if (minutes <= 30) return "Intermediate";
  return "Advanced";
};

// Convert time string to minutes for storage
const timeToMinutes = (timeStr: string): number => {
  // Extract numbers from string, assuming format like "30 minutes" or "1 hour 15 minutes"
  const hourMatch = timeStr.match(/(\d+)\s*h(our)?/i);
  const minuteMatch = timeStr.match(/(\d+)\s*m(in)?/i);
  
  let minutes = 0;
  if (hourMatch) minutes += parseInt(hourMatch[1], 10) * 60;
  if (minuteMatch) minutes += parseInt(minuteMatch[1], 10);
  
  return minutes || 30; // Default to 30 minutes if parsing fails
};

export const handle: typeof generateRecipes = async (options: RecipeRequest): Promise<Recipe[]> => {
  // Validate that ingredients list is not empty
  if (!options.ingredients || options.ingredients.length === 0) {
    throw new Error("Ingredients list cannot be empty");
  }
  
  // Create a description for recipe generation based on user input
  const ingredients = options.ingredients.map(i => i.name).join(", ");
  const dietaryRestrictions = options.dietaryRestrictions?.join(", ") || "None";
  const cuisineType = options.cuisineType || "Any";
  const mealType = options.mealType || "Any";
  const maxPrepTime = options.maxPrepTime || "Any";

  // In a real implementation, this would call an LLM to generate recipes
  // Generating mock recipes for demonstration
  const recipes: Recipe[] = [];
  
  // Simple mock logic to create 3 recipes based on user input
  for (let i = 0; i < 3; i++) {
    const id = randomUUID();
    const prepTime = options.maxPrepTime || "30 minutes";
    const cookTime = "20 minutes";
    
    // Create a recipe name based on inputs
    const name = `${cuisineType !== "Any" ? cuisineType + " " : ""}${
      options.ingredients[0]?.name || "Delicious"
    } ${["Bowl", "Delight", "Special"][i % 3]}`;

    const recipe: Recipe = {
      id,
      name,
      ingredients: [...options.ingredients], // Create a copy to avoid modifying input
      prepTime,
      cookTime,
      servings: 4,
      dietaryTags: options.dietaryRestrictions || ["None"],
      cuisineType: cuisineType !== "Any" ? cuisineType : "International",
      mealType: mealType !== "Any" ? mealType : ["Breakfast", "Lunch", "Dinner"][i % 3],
      difficultyLevel: getDifficultyLevel(prepTime),
    };
    
    recipes.push(recipe);
    
    // Store the recipe in the database
    await db.insert(recipesTable).values({
      id: recipe.id,
      name: recipe.name,
      prepTimeMinutes: timeToMinutes(recipe.prepTime),
      cookTimeMinutes: timeToMinutes(recipe.cookTime),
      servings: recipe.servings,
      cuisineType: recipe.cuisineType,
      mealType: recipe.mealType,
      difficultyLevel: recipe.difficultyLevel,
    });
    
    // Store ingredients and associations
    for (const ingredient of recipe.ingredients) {
      // Check if the ingredient already exists
      const existingIngredient = await db
        .select()
        .from(ingredientsTable)
        .where(eq(ingredientsTable.name, ingredient.name))
        .limit(1);
      
      let ingredientId: number;
      
      if (existingIngredient.length > 0) {
        ingredientId = existingIngredient[0].id;
      } else {
        // Insert new ingredient
        const newIngredient = await db
          .insert(ingredientsTable)
          .values({
            name: ingredient.name,
          })
          .returning({ id: ingredientsTable.id });
          
        ingredientId = newIngredient[0].id;
      }
      
      // Create recipe-ingredient association with quantity
      await db.insert(recipeIngredientsTable).values({
        recipeId: recipe.id,
        ingredientId: ingredientId,
        quantity: ingredient.quantity || null,
        unit: ingredient.unit || null,
      });
    }
    
    // Store dietary restrictions
    if (recipe.dietaryTags && recipe.dietaryTags.length > 0) {
      for (const restriction of recipe.dietaryTags) {
        await db.insert(recipeDietaryRestrictionsTable).values({
          recipeId: recipe.id,
          restriction: restriction,
        });
      }
    }
  }

  return recipes;
};