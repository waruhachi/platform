import { db } from "../db";
import { eq } from "drizzle-orm";
import { saveRecipe, type SaveRecipeRequest } from "../common/schema";
import { 
  recipesTable, 
  recipeIngredientsTable, 
  ingredientsTable,
  recipeDietaryRestrictionsTable 
} from "../db/schema/application";

export const handle: typeof saveRecipe = async (options: SaveRecipeRequest): Promise<void> => {
  // Start a transaction to ensure all related data is saved atomically
  await db.transaction(async (tx) => {
    // 1. Save the recipe basic information
    await tx.insert(recipesTable).values({
      id: options.recipe.id,
      name: options.recipe.name,
      prepTimeMinutes: parseTimeStringToMinutes(options.recipe.prepTime),
      cookTimeMinutes: parseTimeStringToMinutes(options.recipe.cookTime),
      servings: options.recipe.servings,
      cuisineType: options.recipe.cuisineType,
      mealType: options.recipe.mealType,
      difficultyLevel: options.recipe.difficultyLevel,
    }).onConflictDoUpdate({
      target: recipesTable.id,
      set: {
        name: options.recipe.name,
        prepTimeMinutes: parseTimeStringToMinutes(options.recipe.prepTime),
        cookTimeMinutes: parseTimeStringToMinutes(options.recipe.cookTime),
        servings: options.recipe.servings,
        cuisineType: options.recipe.cuisineType,
        mealType: options.recipe.mealType,
        difficultyLevel: options.recipe.difficultyLevel,
        updatedAt: new Date()
      }
    });

    // 2. Clear existing dietary restrictions for this recipe to avoid duplicates
    await tx.delete(recipeDietaryRestrictionsTable)
      .where(eq(recipeDietaryRestrictionsTable.recipeId, options.recipe.id));

    // 3. Save dietary restrictions
    if (options.recipe.dietaryTags.length > 0) {
      const dietaryRestrictionsData = options.recipe.dietaryTags.map(restriction => ({
        recipeId: options.recipe.id,
        restriction: restriction
      }));

      await tx.insert(recipeDietaryRestrictionsTable).values(dietaryRestrictionsData);
    }

    // 4. Clear existing ingredients for this recipe to avoid duplicates
    await tx.delete(recipeIngredientsTable)
      .where(eq(recipeIngredientsTable.recipeId, options.recipe.id));

    // 5. Process ingredients - ensure they exist in ingredients table and connect to recipe
    for (const ingredient of options.recipe.ingredients) {
      // Check if ingredient already exists, create if it doesn't
      const existingIngredients = await tx.select({ id: ingredientsTable.id })
        .from(ingredientsTable)
        .where(eq(ingredientsTable.name, ingredient.name));
      
      let ingredientId: number;

      if (existingIngredients.length === 0) {
        // Create new ingredient
        const newIngredient = await tx.insert(ingredientsTable)
          .values({ name: ingredient.name })
          .returning({ id: ingredientsTable.id });
        
        ingredientId = newIngredient[0].id;
      } else {
        ingredientId = existingIngredients[0].id;
      }

      // Connect ingredient to recipe with quantity information
      await tx.insert(recipeIngredientsTable).values({
        recipeId: options.recipe.id,
        ingredientId: ingredientId,
        quantity: ingredient.quantity || null,
        unit: ingredient.unit || null
      });
    }
  });
};

/**
 * Helper function to parse time strings like "30 minutes", "1 hour 30 minutes", etc. to minutes
 */
function parseTimeStringToMinutes(timeString: string): number {
  timeString = timeString.toLowerCase().trim();
  
  let totalMinutes = 0;
  
  // Extract hours if present
  const hourMatch = timeString.match(/(\d+)\s*hour/);
  if (hourMatch && hourMatch[1]) {
    totalMinutes += parseInt(hourMatch[1], 10) * 60;
  }
  
  // Extract minutes if present
  const minuteMatch = timeString.match(/(\d+)\s*min/);
  if (minuteMatch && minuteMatch[1]) {
    totalMinutes += parseInt(minuteMatch[1], 10);
  }
  
  // If no pattern matched but there's a number, assume it's minutes
  if (totalMinutes === 0) {
    const numericMatch = timeString.match(/(\d+)/);
    if (numericMatch && numericMatch[1]) {
      totalMinutes = parseInt(numericMatch[1], 10);
    }
  }
  
  return totalMinutes;
}