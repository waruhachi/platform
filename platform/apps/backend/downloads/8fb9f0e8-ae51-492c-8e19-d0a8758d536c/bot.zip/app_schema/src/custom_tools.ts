import type { CustomToolHandler } from './common/tool-handler';
import * as schema from './common/schema';



export const custom_handlers: CustomToolHandler[] = [
];