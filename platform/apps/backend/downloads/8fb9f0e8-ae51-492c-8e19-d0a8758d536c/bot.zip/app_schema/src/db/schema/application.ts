import { pgTable, text, integer, timestamp, pgEnum, serial, boolean, jsonb, uniqueIndex } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Dietary restrictions enum
export const dietaryRestrictionEnum = pgEnum("dietary_restriction", [
  "Vegetarian",
  "Vegan",
  "GlutenFree",
  "DairyFree",
  "Keto",
  "Paleo",
  "LowCarb",
  "None"
]);

// Users table
export const usersTable = pgTable("users", {
  id: text().primaryKey(),
  createdAt: timestamp({ withTimezone: true }).defaultNow()
});

// Ingredients table
export const ingredientsTable = pgTable("ingredients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp({ withTimezone: true }).defaultNow()
});

// Recipes table
export const recipesTable = pgTable("recipes", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  prepTimeMinutes: integer("prep_time_minutes").notNull(),
  cookTimeMinutes: integer("cook_time_minutes").notNull(),
  servings: integer("servings").notNull(),
  cuisineType: text("cuisine_type").notNull(),
  mealType: text("meal_type").notNull(),
  difficultyLevel: text("difficulty_level").notNull(),
  createdAt: timestamp({ withTimezone: true }).defaultNow(),
  updatedAt: timestamp({ withTimezone: true }).defaultNow()
});

// Recipe relations
export const recipesRelations = relations(recipesTable, ({ many }) => ({
  recipeIngredients: many(recipeIngredientsTable),
  recipeDietaryRestrictions: many(recipeDietaryRestrictionsTable),
  recipeDetails: many(recipeDetailsTable),
  userFavorites: many(userFavoritesTable)
}));

// Recipe ingredients join table with quantities
export const recipeIngredientsTable = pgTable("recipe_ingredients", {
  id: serial("id").primaryKey(),
  recipeId: text("recipe_id").references(() => recipesTable.id, { onDelete: "cascade" }).notNull(),
  ingredientId: integer("ingredient_id").references(() => ingredientsTable.id, { onDelete: "cascade" }).notNull(),
  quantity: text("quantity"),
  unit: text("unit"),
}, (t) => ({
  uniqueRecipeIngredient: uniqueIndex("recipe_ingredient_unique_idx").on(t.recipeId, t.ingredientId)
}));

// Recipe ingredients relations
export const recipeIngredientsRelations = relations(recipeIngredientsTable, ({ one }) => ({
  recipe: one(recipesTable, {
    fields: [recipeIngredientsTable.recipeId],
    references: [recipesTable.id]
  }),
  ingredient: one(ingredientsTable, {
    fields: [recipeIngredientsTable.ingredientId],
    references: [ingredientsTable.id]
  })
}));

// Recipe dietary restrictions join table
export const recipeDietaryRestrictionsTable = pgTable("recipe_dietary_restrictions", {
  id: serial("id").primaryKey(),
  recipeId: text("recipe_id").references(() => recipesTable.id, { onDelete: "cascade" }).notNull(),
  restriction: dietaryRestrictionEnum("restriction").notNull()
}, (t) => ({
  uniqueRestriction: uniqueIndex("recipe_restriction_unique_idx").on(t.recipeId, t.restriction)
}));

// Recipe dietary restrictions relations
export const recipeDietaryRestrictionsRelations = relations(recipeDietaryRestrictionsTable, ({ one }) => ({
  recipe: one(recipesTable, {
    fields: [recipeDietaryRestrictionsTable.recipeId],
    references: [recipesTable.id]
  })
}));

// Recipe details table
export const recipeDetailsTable = pgTable("recipe_details", {
  id: serial("id").primaryKey(),
  recipeId: text("recipe_id").references(() => recipesTable.id, { onDelete: "cascade" }).notNull().unique(),
  instructions: jsonb("instructions").$type<string[]>().notNull(),
  nutritionalInfo: text("nutritional_info"),
  createdAt: timestamp({ withTimezone: true }).defaultNow(),
  updatedAt: timestamp({ withTimezone: true }).defaultNow()
});

// Recipe details relations
export const recipeDetailsRelations = relations(recipeDetailsTable, ({ one }) => ({
  recipe: one(recipesTable, {
    fields: [recipeDetailsTable.recipeId],
    references: [recipesTable.id]
  })
}));

// User favorites table
export const userFavoritesTable = pgTable("user_favorites", {
  id: serial("id").primaryKey(),
  userId: text("user_id").references(() => usersTable.id, { onDelete: "cascade" }).notNull(),
  recipeId: text("recipe_id").references(() => recipesTable.id, { onDelete: "cascade" }).notNull(),
  savedAt: timestamp({ withTimezone: true }).defaultNow()
}, (t) => ({
  uniqueUserFavorite: uniqueIndex("user_favorite_unique_idx").on(t.userId, t.recipeId)
}));

// User favorites relations
export const userFavoritesRelations = relations(userFavoritesTable, ({ one }) => ({
  user: one(usersTable, {
    fields: [userFavoritesTable.userId],
    references: [usersTable.id]
  }),
  recipe: one(recipesTable, {
    fields: [userFavoritesTable.recipeId],
    references: [recipesTable.id]
  })
}));