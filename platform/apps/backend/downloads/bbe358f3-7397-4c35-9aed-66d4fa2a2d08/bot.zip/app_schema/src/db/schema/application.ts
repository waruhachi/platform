import { 
  pgTable, 
  text, 
  varchar, 
  date, 
  timestamp, 
  integer, 
  real, 
  pgEnum, 
  boolean,
  primaryKey,
  uuid
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Enums
export const priorityEnum = pgEnum('priority', ['low', 'medium', 'high', 'critical']);
export const statusEnum = pgEnum('status', ['not_started', 'in_progress', 'completed', 'blocked', 'deferred']);
export const roleEnum = pgEnum('role', ['developer', 'designer', 'tester', 'manager', 'qa', 'ux_designer', 'other']);

// Projects table
export const projects = pgTable('projects', {
  id: uuid().primaryKey().defaultRandom(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  startDate: date('start_date').notNull(),
  endDate: date('end_date'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Team members table
export const teamMembers = pgTable('team_members', {
  id: uuid().primaryKey().defaultRandom(),
  name: varchar('name', { length: 255 }).notNull(),
  role: roleEnum('role').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Project-team member relationship (many-to-many)
export const projectTeamMembers = pgTable('project_team_members', {
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  teamMemberId: uuid('team_member_id').references(() => teamMembers.id, { onDelete: 'cascade' }).notNull()
}, (t) => ({
  pk: primaryKey({ columns: [t.projectId, t.teamMemberId] })
}));

// Tasks table
export const tasks = pgTable('tasks', {
  id: uuid().primaryKey().defaultRandom(),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  priority: priorityEnum('priority').notNull().default('medium'),
  dueDate: date('due_date'),
  estimatedHours: real('estimated_hours'),
  completionPercentage: integer('completion_percentage').default(0),
  status: statusEnum('status').default('not_started').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// Task status updates table
export const taskStatusUpdates = pgTable('task_status_updates', {
  id: uuid().primaryKey().defaultRandom(),
  taskId: uuid('task_id').references(() => tasks.id, { onDelete: 'cascade' }).notNull(),
  status: statusEnum('status').notNull(),
  completionPercentage: integer('completion_percentage').notNull(),
  notes: text('notes'),
  updatedDate: timestamp('updated_date').notNull().defaultNow(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

// Task assignments table
export const taskAssignments = pgTable('task_assignments', {
  id: uuid().primaryKey().defaultRandom(),
  taskId: uuid('task_id').references(() => tasks.id, { onDelete: 'cascade' }).notNull(),
  assigneeId: uuid('assignee_id').references(() => teamMembers.id, { onDelete: 'cascade' }).notNull(),
  assignedDate: timestamp('assigned_date').notNull().defaultNow(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  active: boolean('active').default(true).notNull()
});

// Reports table (for storing generated reports)
export const reports = pgTable('reports', {
  id: uuid().primaryKey().defaultRandom(),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }).notNull(),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  includeCompletedTasks: boolean('include_completed_tasks').default(true).notNull(),
  reportData: text('report_data'), // JSON data stored as text
  generatedAt: timestamp('generated_at').defaultNow().notNull()
});

// Define relations
export const projectsRelations = relations(projects, ({ many }) => ({
  teamMembers: many(projectTeamMembers),
  tasks: many(tasks)
}));

export const teamMembersRelations = relations(teamMembers, ({ many }) => ({
  projects: many(projectTeamMembers),
  taskAssignments: many(taskAssignments)
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id]
  }),
  statusUpdates: many(taskStatusUpdates),
  assignments: many(taskAssignments)
}));

export const taskAssignmentsRelations = relations(taskAssignments, ({ one }) => ({
  task: one(tasks, {
    fields: [taskAssignments.taskId],
    references: [tasks.id]
  }),
  assignee: one(teamMembers, {
    fields: [taskAssignments.assigneeId],
    references: [teamMembers.id]
  })
}));

export const taskStatusUpdatesRelations = relations(taskStatusUpdates, ({ one }) => ({
  task: one(tasks, {
    fields: [taskStatusUpdates.taskId],
    references: [tasks.id]
  })
}));

export const projectTeamMembersRelations = relations(projectTeamMembers, ({ one }) => ({
  project: one(projects, {
    fields: [projectTeamMembers.projectId],
    references: [projects.id]
  }),
  teamMember: one(teamMembers, {
    fields: [projectTeamMembers.teamMemberId],
    references: [teamMembers.id]
  })
}));