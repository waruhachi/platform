import { resetDB } from '.';

resetDB().then(() => console.log('DB reset successfully'));
