import * as schema from './common/schema';
import type { ToolHandler } from './common/tool-handler';


export const handlers: ToolHandler<any>[] = [
];